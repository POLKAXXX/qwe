# Игра Шашки на Python
## Скриншот

<p align="center">
  <img src="https://github.com/Kicshikxo/Python-checkers/blob/master/screenshot.png?raw=true" alt="Gameplay screenshot"/>
</p>

## Описание проекта
Игра Шашки, написанная на Python с использованием графической библиотеки Tkinter.  
В игре присутствует экспертная система, представленная алгоритмом для нахождения оптимального хода у вражеских шашек.

Разработка велась на Python 3.9.7
